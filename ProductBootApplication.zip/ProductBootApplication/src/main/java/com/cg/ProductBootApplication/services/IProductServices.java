package com.cg.ProductBootApplication.services;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.ProductBootApplication.beans.Product;


public interface IProductServices 
{
   public Product acceptProductDetails(Product product);
   public List<Product> showAll();
   
}
