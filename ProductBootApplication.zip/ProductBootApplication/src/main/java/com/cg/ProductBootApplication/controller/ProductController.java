package com.cg.ProductBootApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductBootApplication.beans.Product;
import com.cg.ProductBootApplication.services.ProductServicesImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ProductController 
{
   @Autowired
   ProductServicesImpl ps;
   
   @RequestMapping(value="/acceptProductDetails", method=RequestMethod.POST)
   public ResponseEntity<String> getAcceptProductDetails(@ModelAttribute Product product)
   {
	   product = ps.acceptProductDetails(product);
   	return new ResponseEntity<String>("Product Details Accepted Successfully!\n" + product,HttpStatus.OK);
   }
   
   @RequestMapping(value= {"/getAllProductDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
	  		headers="Accept=application/json")
	  public ResponseEntity<List<Product>> getAllProductDetailsPathParam()
	  {
	  	return new ResponseEntity<List<Product>>(ps.showAll(),HttpStatus.OK);
	  }
	  
}
