package com.cg.ProductBootApplication.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ProductBootApplication.beans.Product;

public interface ProductDAO extends JpaRepository<Product, Integer>{

}
