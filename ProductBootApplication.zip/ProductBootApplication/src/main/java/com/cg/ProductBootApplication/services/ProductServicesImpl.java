package com.cg.ProductBootApplication.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.ProductBootApplication.beans.Product;
import com.cg.ProductBootApplication.dao.ProductDAO;

@Component
public class ProductServicesImpl implements IProductServices
{
	@Autowired
	ProductDAO p;

	@Override
	public Product acceptProductDetails(Product product) {
		product = p.save(product);
		return product;
	}

	@Override
	public List<Product> showAll() {
		return p.findAll();
	}
   
}
